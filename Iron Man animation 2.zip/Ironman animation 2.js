function stoperror(){
  return true;
}
window.onerror = stoperror;

// When DOM is ready
window.onload = function() {
  
  // Select * path elements (in css they are displayed to none)  
  var paths = document.querySelectorAll("path");
  
  // Array container for my new paths to access shift() below
  var newPaths = [];
  
  for (var i = 0; i < paths.length; i++){
    // Push all paths into my newPaths array  
    newPaths.push(paths[i]);
  }
  
  
    
  function foo(){
      
    // If newPaths.length !== 0
    if(newPaths.length !== 0){
        
      // Display all newPaths from my array one by one
      // By changing from display: none to display: flex
      newPaths.shift().style.display = "flex";
    }
  } // End of bar
  
// Run my function
setInterval(foo, 100);

}; // End of onload function