@import url('https://fonts.googleapis.com/css2?family=Anton&family=Chelsea+Market&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Open+Sans+Condensed:wght@300;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap');

*{
    box-sizing:border-box;
}
body {
    margin:0;
    padding:0;
    /*background-color:black;*/
    background-image:url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSjAj-IFUj8s60fMnhDIbPQZp8GgB5JnZ_zQ&usqp=CAU");
    background-size:cover;
}
#top{
    width:100%;
    height:55px;
    background-color:none;
    position:fixed;
    border-bottom:solid 5px lightgray;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:0 15px 0 15px;
    backdrop-filter:blur(20px) opacity(0.5);
    font-family: 'Chelsea Market', cursive;
}
#inp{
    width:80%;
    height:70%;
    padding:15px;
    border-radius:1000px;
    border-style:solid;
    margin-left:30vw;
}
svg{
    height:80%;
}
#scroll{
    position:fixed;
    top:50px;
    left:0;
    width:0%;
    background-color:red;
    height:5px;
}
#all_ele{
    position:fixed;
    top:60px;
    width:100%;
    height:calc(100vh - 60px);
    background-color:none;
    padding:15px 20px 15px 20px;
    overflow:scroll;
    font-size:20px;
    color:white;
    font-family: 'Patrick Hand', cursive;
}
.lst{
    width:100%;
    padding:15px;
    margin-bottom:15px;
    border:solid 1px black;
    border-radius:5px;
    position:relative;
    backdrop-filter: blur(5px) opacity(0.8);
    text-transform:capitalize;
}